# Changes in version 0.0.2

* Added `surplus_irm` function with class `surplusirm`

# Changes in version 0.0.1

* Added `surplus` function with class `surplus`
* Added print and plot method for surplus
* Added an interactive shiny app to demonstrate the surplus function
