# The `ds` package

## About
This package contains a personal collection of functions used for training and demonstration purpose only. 

## Instalation 

`install_github("Poduval/ds/release/ds")`

## Reference
Build R packages: http://r-pkgs.had.co.nz/

## Final product
`ds.tar.gz`
