# `ds` (Dr. Dibu A.S's course work)

## About
This package contains a personal collection of functions used for training and demonstration purpose only. 

### Authors

1. Dr. Dibu A.S: <https://www.linkedin.com/in/dasachudham/>
2. Rakesh Poduval: <https://www.linkedin.com/in/poduvalrakesh/>

## Instalation 

`install_github("Poduval/ds")`

## Contents

1. Surplus function of the insurer.
2. Surplus function for individual risk model.
